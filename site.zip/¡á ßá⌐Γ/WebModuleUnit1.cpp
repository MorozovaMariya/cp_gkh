
//---------------------------------------------------------------------------
#include "WebModuleUnit1.h"
#include <vcl.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TComponentClass WebModuleClass = __classid(TWebModule1);
//---------------------------------------------------------------------------
__fastcall TWebModule1::TWebModule1(TComponent* Owner)
	: TWebModule(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TWebModule1::WebModule1DefaultHandlerAction(TObject *Sender, TWebRequest *Request,
          TWebResponse *Response, bool &Handled)
{

//  Response->Content =
////    "<html>"
////	"<head><title>Web Server Application</title></head>"
////	"<body>Web Server Application</body>"
////	"</html>";
//
//"<!DOCTYPE html>"
//"<html>"
//"   <head>"
//"      <meta charset=\"utf-8\" />"
//"      <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
//"      <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />"
//"      <!--metatextblock-->"
//"      <title>SmartTyumen</title>"
//"      <meta property=\"og:url\" content=\"http://smarttyumen.tilda.ws\" />"
//"      <meta property=\"og:title\" content=\"SmartTyumen\" />"
//"      <meta property=\"og:description\" content=\"\" />"
//"      <meta property=\"og:type\" content=\"website\" />"
//"      <link rel=\"canonical\" href=\"http://smarttyumen.tilda.ws/\">"
//"      <!--/metatextblock-->"
//"      <meta property=\"fb:app_id\" content=\"257953674358265\" />"
//"      <meta name=\"format-detection\" content=\"telephone=no\" />"
//"      <meta http-equiv=\"x-dns-prefetch-control\" content=\"on\">"
//"      <link rel=\"dns-prefetch\" href=\"https://tilda.ws\">"
//"      <link rel=\"dns-prefetch\" href=\"https://static.tildacdn.com\">"
//"      <meta name=\"robots\" content=\"nofollow\" />"
//"      <link rel=\"shortcut icon\" href=\"https://static.tildacdn.com/img/tildafavicon.ico\" type=\"image/x-icon\" />"
//"      <!-- Assets -->"
//"      <link rel=\"stylesheet\" href=\"https://static.tildacdn.com/css/tilda-grid-3.0.min.css\" type=\"text/css\" media=\"all\" />"
//"      <link rel=\"stylesheet\" href=\"https://tilda.ws/project733847/tilda-blocks-2.12.css?t=1562415924\" type=\"text/css\" media=\"all\" />"
//"      <link rel=\"stylesheet\" href=\"https://static.tildacdn.com/css/tilda-animation-1.0.min.css\" type=\"text/css\" media=\"all\" />"
//"      <link rel=\"stylesheet\" href=\"https://static.tildacdn.com/css/tilda-slds-1.4.min.css\" type=\"text/css\" media=\"all\" />"
//"      <link rel=\"stylesheet\" href=\"https://static.tildacdn.com/css/tilda-zoom-2.0.min.css\" type=\"text/css\" media=\"all\" />"
//"      <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Oswald|Roboto&display=swap\" type=\"text/css\" />"
//"      <script src=\"https://static.tildacdn.com/js/jquery-1.10.2.min.js\"></script><script src=\"https://static.tildacdn.com/js/tilda-scripts-2.8.min.js\"></script><script src=\"https://tilda.ws/project733847/tilda-blocks-2.7.js?t=1562415924\"></script><script src=\"https://static.tildacdn.com/js/lazyload-1.3.min.js\" charset=\"utf-8\"></script><script src=\"https://static.tildacdn.com/js/tilda-animation-1.0.min.js\" charset=\"utf-8\"></script><script src=\"https://static.tildacdn.com/js/tilda-slds-1.4.min.js\" charset=\"utf-8\"></script><script src=\"https://static.tildacdn.com/js/hammer.min.js\" charset=\"utf-8\"></script><script src=\"https://static.tildacdn.com/js/tilda-zoom-2.0.min.js\" charset=\"utf-8\"></script><script type=\"text/javascript\">window.dataLayer = window.dataLayer || [];</script><script type=\"text/javascript\">if((/bot|google|yandex|baidu|bing|msn|duckduckbot|teoma|slurp|crawler|spider|robot|crawling|facebook/i.test(navigator.userAgent))===false && typeof(sessionStorage)!='undefined' && sessionStorage.getItem('visited')!=='y'){	var style=document.createElement('style');	style.type='text/css';	style.innerHTML='@media screen and (min-width: 980px) {.t-records {opacity: 0;}.t-records_animated {-webkit-transition: opacity ease-in-out .2s;-moz-transition: opacity ease-in-out .2s;-o-transition: opacity ease-in-out .2s;transition: opacity ease-in-out .2s;}.t-records.t-records_visible {opacity: 1;}}';	document.getElementsByTagName('head')[0].appendChild(style);	$(document).ready(function() { $('.t-records').addClass('t-records_animated'); setTimeout(function(){ $('.t-records').addClass('t-records_visible'); sessionStorage.setItem('visited','y'); },400);	});"
//"         }"
//"      </script>"
//"   </head>"
//"   <body class=\"t-body\" style=\"margin:0;\">"
//"      <!--allrecords-->"
//"      <div id=\"allrecords\" class=\"t-records\" data-hook=\"blocks-collection-content-node\" data-tilda-project-id=\"733847\" data-tilda-page-id=\"5359855\" data-tilda-formskey=\"e53b1405b79e4b52f2552f06bd83a7e8\" >"
//"         <div id=\"rec97244687\" class=\"r t-rec t-rec_pb_0\" style=\"padding-bottom:0px; \" data-animationappear=\"off\" data-record-type=\"396\" >"
//"            <!-- T396 -->"
//"            <style>#rec97244687 .t396__artboard{height: 720px;background-color: #f4f4f7;}#rec97244687 .t396__filter{height: 720px;}#rec97244687 .t396__carrier{height: 720px;background-position: center center;background-attachment: scroll;background-size:cover;background-repeat:no-repeat;}@media screen and (max-width: 1199px){#rec97244687 .t396__artboard{}#rec97244687 .t396__filter{}#rec97244687 .t396__carrier{background-attachment:scroll;}}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97244687 .tn-elem[data-elem-id=\"1562403135580\"]{color:#000000;z-index:10;top: 40px;left: calc(50% - 600px + 150px);width:110px;}#rec97244687 .tn-elem[data-elem-id=\"1562403135580\"] .tn-atom{color:#000000;font-size:17px;font-family:'Roboto',Arial,sans-serif;line-height:1.55;font-weight:500;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97244687 .tn-elem[data-elem-id=\"1562404016502\"]{color:#000000;z-index:11;top: 40px;left: calc(50% - 600px + 720px);width:110px;}#rec97244687 .tn-elem[data-elem-id=\"1562404016502\"] .tn-atom{color:#000000;font-size:13px;font-family:'Roboto',Arial,sans-serif;line-height:1.55;font-weight:300;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97244687 .tn-elem[data-elem-id=\"1562404087219\"]"
//"			{color:#000000;z-index:12;top: 40px;left: calc(50% - 600px + 820px);width:70px;}#rec97244687 .tn-elem[data-elem-id=\"1562404087219\"] .tn-atom{color:#000000;font-size:13px;font-family:'Roboto',Arial,sans-serif;line-height:1.55;font-weight:300;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97244687 .tn-elem[data-elem-id=\"1562404269370\"]{color:#ffffff;text-align:center;z-index:14;top: 360px;left: calc(50% - 600px + 120px);width:200px;height:55px;}#rec97244687 .tn-elem[data-elem-id=\"1562404269370\"] .tn-atom{color:#ffffff;font-size:14px;font-family:'Roboto',Arial,sans-serif;line-height:1.55;font-weight:600;border-width:1px;border-radius:30px;background-color:#f76a20;background-position:center center;border-color:transparent;border-style:solid;transition: background-color 0.2s ease-in-out, color 0.2s ease-in-out, border-color 0.2s ease-in-out;box-shadow: 0px 0px 0px 0px rgba(0,0,0,1);}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97244687 .tn-elem[data-elem-id=\"1562404386124\"]{z-index:8;top: 310px;left: calc(50% - 600px + 510px);width:850px;}#rec97244687 .tn-elem[data-elem-id=\"1562404386124\"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and "
//"			(max-width: 479px){}#rec97244687 .tn-elem[data-elem-id=\"1562404510168\"]{color:#000000;z-index:16;top: 40px;left: calc(50% - 600px + 920px);width:110px;}#rec97244687 .tn-elem[data-elem-id=\"1562404510168\"] .tn-atom{color:#000000;font-size:13px;font-family:'Roboto',Arial,sans-serif;line-height:1.55;font-weight:300;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97244687 .tn-elem[data-elem-id=\"1562405545736\"]{color:#000000;z-index:17;top: 200px;left: calc(50% - 600px + 120px);width:560px;}#rec97244687 .tn-elem[data-elem-id=\"1562405545736\"] .tn-atom{color:#000000;font-size:66px;font-family:'Oswald',Arial,sans-serif;line-height:1;font-weight:300;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97244687 .tn-elem[data-elem-id=\"1562403046185\"]{z-index:9;top: 111px;left: calc(50% - 600px + 509px);width:789px;}#rec97244687 .tn-elem[data-elem-id=\"1562403046185\"] .tn-atom{background-position:center center;border-color:#f4f1ea;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97244687 .tn-elem[data-elem-id=\"1562408717076\"]{z-index:6;top: -50px;left: calc(50% - 600px + 440px);width:929px;}#rec97244687 .tn-elem[data-elem-id=\"1562408717076\"] "
//"			.tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97244687 .tn-elem[data-elem-id=\"1562413038565\"]{z-index:5;top: 360px;left: calc(50% - 600px + 350px);width:1130px;}#rec97244687 .tn-elem[data-elem-id=\"1562413038565\"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}</style>"
//"            <div class='t396'>"
//"               <div class=\"t396__artboard\" data-artboard-recid=\"97244687\"	data-artboard-height=\"720\"	data-artboard-height_vh=\"\"	data-artboard-valign=\"center\"	data-artboard-ovrflw=\"\"	>"
//"                  <div class=\"t396__carrier\" data-artboard-recid=\"97244687\"></div>"
//"                  <div class=\"t396__filter\" data-artboard-recid=\"97244687\"></div>"
//"                  <div class='t396__elem tn-elem tn-elem__972446871562403135580' data-elem-id='1562403135580' data-elem-type='text'	data-field-top-value=\"40\"	data-field-left-value=\"150\"	data-field-width-value=\"110\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' field='tn_text_1562403135580' >Clever TMN</div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972446871562404016502' data-elem-id='1562404016502' data-elem-type='text'	data-field-top-value=\"40\"	data-field-left-value=\"720\"	data-field-width-value=\"110\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' field='tn_text_1562404016502' >� ���</div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972446871562404087219' data-elem-id='1562404087219' data-elem-type='text'	data-field-top-value=\"40\"	data-field-left-value=\"820\"	data-field-width-value=\"70\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' field='tn_text_1562404087219' >��������</div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972446871562404269370' data-elem-id='1562404269370' data-elem-type='button'	data-field-top-value=\"360\"	data-field-left-value=\"120\"	data-field-height-value=\"55\"	data-field-width-value=\"200\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" > <a class='tn-atom' href=\" #rec97269753\" >����������</a> </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972446871562404386124' data-elem-id='1562404386124' data-elem-type='image'	data-field-top-value=\"310\"	data-field-left-value=\"510\"	data-field-width-value=\"850\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' > <img class='tn-atom__img t-img' data-original='https://static.tildacdn.com/tild3236-3066-4631-a361-623062633566/StockGraphicDesigns-.png' imgfield='tn_img_1562404386124'> </div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972446871562404510168' data-elem-id='1562404510168' data-elem-type='text'	data-field-top-value=\"40\"	data-field-left-value=\"920\"	data-field-width-value=\"110\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' field='tn_text_1562404510168' >�������</div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972446871562405545736' data-elem-id='1562405545736' data-elem-type='text'	data-field-top-value=\"200\"	data-field-left-value=\"120\"	data-field-width-value=\"560\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' field='tn_text_1562405545736' >���������� ���.<br>��� �������</div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972446871562403046185' data-elem-id='1562403046185' data-elem-type='image'	data-field-top-value=\"111\"	data-field-left-value=\"509\"	data-field-width-value=\"789\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' > <img class='tn-atom__img t-img' data-original='https://static.tildacdn.com/tild6533-3164-4765-b866-346338393539/_.png' imgfield='tn_img_1562403046185'> </div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972446871562408717076' data-elem-id='1562408717076' data-elem-type='image'	data-field-top-value=\"-50\"	data-field-left-value=\"440\"	data-field-width-value=\"929\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' > <img class='tn-atom__img t-img' data-original='https://static.tildacdn.com/tild3662-6630-4536-b131-633931396134/__.png' imgfield='tn_img_1562408717076'> </div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972446871562413038565' data-elem-id='1562413038565' data-elem-type='image'	data-field-top-value=\"360\"	data-field-left-value=\"350\"	data-field-width-value=\"1130\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' > <img class='tn-atom__img t-img' data-original='https://static.tildacdn.com/tild6234-3534-4737-b766-636638643639/bg_2.png' imgfield='tn_img_1562413038565'> </div>"
//"                  </div>"
//"               </div>"
//"            </div>"
//"            <script>$( document ).ready(function() { t396_init('97244687');"
//"               });"
//"            </script><!-- /T396 -->"
//"         </div>"
//"         <div id=\"rec97269753\" class=\"r t-rec t-rec_pb_60\" style=\"padding-bottom:60px; \" data-animationappear=\"off\" data-record-type=\"396\" >"
//"            <!-- T396 -->"
//"            <style>#rec97269753 .t396__artboard{height: 810px;background-color: #f4f4f7;}#rec97269753 .t396__filter{height: 810px;}#rec97269753 .t396__carrier{height: 810px;background-position: center center;background-attachment: scroll;background-size:cover;background-repeat:no-repeat;}@media screen and (max-width: 1199px){#rec97269753 .t396__artboard{}#rec97269753 .t396__filter{}#rec97269753 .t396__carrier{background-attachment:scroll;}}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562407200320\"]{color:#000000;z-index:4;top: 50px;left: calc(50% - 600px + 220px);width:409px;}#rec97269753 .tn-elem[data-elem-id=\"1562407200320\"] .tn-atom{color:#000000;font-size:75px;font-family:'Roboto',Arial,sans-serif;line-height:1;font-weight:700;opacity:0.8;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562407267231\"]{color:#000000;z-index:5;top: 120px;left: calc(50% - 600px + 220px);width:409px;}#rec97269753 .tn-elem[data-elem-id=\"1562407267231\"] .tn-atom{color:#000000;font-size:75px;font-family:'Roboto',Arial,sans-serif;line-height:1;font-weight:700;opacity:0.8;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and "
//"			(max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562407363887\"]{color:#000000;z-index:6;top: 266px;left: calc(50% - 600px + 320px);width:209px;}#rec97269753 .tn-elem[data-elem-id=\"1562407363887\"] .tn-atom{color:#000000;font-size:16px;font-family:'Roboto',Arial,sans-serif;line-height:1.55;font-weight:400;opacity:0.6;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562407380895\"]{color:#000000;z-index:7;top: 396px;left: calc(50% - 600px + 320px);width:209px;}#rec97269753 .tn-elem[data-elem-id=\"1562407380895\"] .tn-atom{color:#000000;font-size:16px;font-family:'Roboto',Arial,sans-serif;line-height:1.55;font-weight:400;opacity:0.6;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562407389080\"]{color:#000000;z-index:8;top: 336px;left: calc(50% - 600px + 320px);width:209px;}#rec97269753 .tn-elem[data-elem-id=\"1562407389080\"] .tn-atom{color:#000000;font-size:16px;font-family:'Roboto',Arial,sans-serif;line-height:1.55;font-weight:400;opacity:0.6;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and "
//"			(max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562407411720\"]{color:#000000;z-index:9;top: 456px;left: calc(50% - 600px + 320px);width:209px;}#rec97269753 .tn-elem[data-elem-id=\"1562407411720\"] .tn-atom{color:#000000;font-size:16px;font-family:'Roboto',Arial,sans-serif;line-height:1.55;font-weight:400;opacity:0.6;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562407446705\"]{z-index:10;top: 116px;left: calc(50% - 600px + 524px);width:100px;height:5px;}#rec97269753 .tn-elem[data-elem-id=\"1562407446705\"] .tn-atom{background-color:#f76a20;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562408076681\"]{z-index:14;top: 308px;left: calc(50% - 600px + 317px);width:500px;height:4px;}#rec97269753 .tn-elem[data-elem-id=\"1562408076681\"] .tn-atom{opacity:0.85;background-color:#363635;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562408135750\"]{z-index:15;top: 372px;left: calc(50% - 600px + 317px);"
//"			width:500px;height:4px;}#rec97269753 .tn-elem[data-elem-id=\"1562408135750\"] .tn-atom{opacity:0.5;background-color:#c4c4c4;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562408137761\"]{z-index:16;top: 436px;left: calc(50% - 600px + 317px);width:500px;height:4px;}#rec97269753 .tn-elem[data-elem-id=\"1562408137761\"] .tn-atom{opacity:0.5;background-color:#c4c4c4;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562408144154\"]{z-index:17;top: 494px;left: calc(50% - 600px + 317px);width:500px;height:4px;}#rec97269753 .tn-elem[data-elem-id=\"1562408144154\"] .tn-atom{opacity:0.5;background-color:#c4c4c4;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562409289923\"]{z-index:20;top: 550px;left: calc(50% - 600px + 316px);width:500px;height:4px;}#rec97269753 .tn-elem[data-elem-id=\"1562409289923\"] .tn-atom{opacity:0.5;background-color:#c4c4c4;background-position:center center;border-color:transparent;border-style:solid;}@media screen and "
//"			(max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562408335277\"]{z-index:18;top: 420px;left: calc(50% - 600px + 850px);width:200px;}#rec97269753 .tn-elem[data-elem-id=\"1562408335277\"] .tn-atom{-webkit-transform:rotate(90deg); -moz-transform:rotate(90deg); transform:rotate(90deg);background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562410469426\"]{color:#ffffff;text-align:center;z-index:21;top: 680px;left: calc(50% - 600px + 700px);width:126px;height:53px;}#rec97269753 .tn-elem[data-elem-id=\"1562410469426\"] .tn-atom{color:#ffffff;font-size:14px;font-family:'Arial',Arial,sans-serif;line-height:1.55;font-weight:600;border-width:1px;border-radius:30px;background-color:#f76a20;background-position:center center;border-color:transparent;border-style:solid;transition: background-color 0.2s ease-in-out, color 0.2s ease-in-out, border-color 0.2s ease-in-out;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec97269753 .tn-elem[data-elem-id=\"1562410679389\"]{color:#ffffff;text-align:center;z-index:23;top: 592px;left: calc(50% - 600px + 320px);width:140px;height:131px;}#rec97269753 .tn-elem[data-elem-id=\"1562410679389\"] "
//"			.tn-atom{color:#ffffff;font-size:14px;font-family:'Arial',Arial,sans-serif;line-height:1.55;font-weight:600;border-width:1px;border-radius:10px;background-color:#f76a20;background-position:center center;border-color:transparent;border-style:solid;transition: background-color 0.2s ease-in-out, color 0.2s ease-in-out, border-color 0.2s ease-in-out;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}</style>"
//"            <div class='t396'>"
//"               <div class=\"t396__artboard\" data-artboard-recid=\"97269753\"	data-artboard-height=\"810\"	data-artboard-height_vh=\"\"	data-artboard-valign=\"center\"	data-artboard-ovrflw=\"\"	>"
//"                  <div class=\"t396__carrier\" data-artboard-recid=\"97269753\"></div>"
//"                  <div class=\"t396__filter\" data-artboard-recid=\"97269753\"></div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562407200320' data-elem-id='1562407200320' data-elem-type='text'	data-field-top-value=\"50\"	data-field-left-value=\"220\"	data-field-width-value=\"409\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' field='tn_text_1562407200320' >��� ��� <br><br></div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562407267231' data-elem-id='1562407267231' data-elem-type='text'	data-field-top-value=\"120\"	data-field-left-value=\"220\"	data-field-width-value=\"409\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' field='tn_text_1562407267231' >���������?<br><br></div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562407363887' data-elem-id='1562407363887' data-elem-type='text'	data-field-top-value=\"266\"	data-field-left-value=\"320\"	data-field-width-value=\"209\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' field='tn_text_1562407363887' >��� �������</div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562407380895' data-elem-id='1562407380895' data-elem-type='text'	data-field-top-value=\"396\"	data-field-left-value=\"320\"	data-field-width-value=\"209\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' field='tn_text_1562407380895' >E-mail</div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562407389080' data-elem-id='1562407389080' data-elem-type='text'	data-field-top-value=\"336\"	data-field-left-value=\"320\"	data-field-width-value=\"209\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' field='tn_text_1562407389080' >�����</div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562407411720' data-elem-id='1562407411720' data-elem-type='text'	data-field-top-value=\"456\"	data-field-left-value=\"320\"	data-field-width-value=\"209\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' field='tn_text_1562407411720' >��������</div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562407446705' data-elem-id='1562407446705' data-elem-type='shape'	data-field-top-value=\"116\"	data-field-left-value=\"524\"	data-field-height-value=\"5\"	data-field-width-value=\"100\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' > </div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562408076681' data-elem-id='1562408076681' data-elem-type='shape'	data-field-top-value=\"308\"	data-field-left-value=\"317\"	data-field-height-value=\"4\"	data-field-width-value=\"500\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' > </div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562408135750' data-elem-id='1562408135750' data-elem-type='shape'	data-field-top-value=\"372\"	data-field-left-value=\"317\"	data-field-height-value=\"4\"	data-field-width-value=\"500\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' > </div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562408137761' data-elem-id='1562408137761' data-elem-type='shape'	data-field-top-value=\"436\"	data-field-left-value=\"317\"	data-field-height-value=\"4\"	data-field-width-value=\"500\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' > </div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562408144154' data-elem-id='1562408144154' data-elem-type='shape'	data-field-top-value=\"494\"	data-field-left-value=\"317\"	data-field-height-value=\"4\"	data-field-width-value=\"500\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' > </div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562409289923' data-elem-id='1562409289923' data-elem-type='shape'	data-field-top-value=\"550\"	data-field-left-value=\"316\"	data-field-height-value=\"4\"	data-field-width-value=\"500\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' > </div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562408335277' data-elem-id='1562408335277' data-elem-type='image'	data-field-top-value=\"420\"	data-field-left-value=\"850\"	data-field-width-value=\"200\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' > <img class='tn-atom__img t-img' data-original='https://static.tildacdn.com/tild6531-3765-4433-a466-333132393062/icons8----filled-100.png' imgfield='tn_img_1562408335277'> </div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562410469426' data-elem-id='1562410469426' data-elem-type='button'	data-field-top-value=\"680\"	data-field-left-value=\"700\"	data-field-height-value=\"53\"	data-field-width-value=\"126\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' >���������</div>"
//"                  </div>"
//"                  <div class='t396__elem tn-elem tn-elem__972697531562410679389' data-elem-id='1562410679389' data-elem-type='button'	data-field-top-value=\"592\"	data-field-left-value=\"320\"	data-field-height-value=\"131\"	data-field-width-value=\"140\"	data-field-axisy-value=\"top\"	data-field-axisx-value=\"left\"	data-field-container-value=\"grid\"	data-field-topunits-value=\"\"	data-field-leftunits-value=\"\"	data-field-heightunits-value=\"\"	data-field-widthunits-value=\"\" >"
//"                     <div class='tn-atom' ></div>"
//"                  </div>"
//"               </div>"
//"            </div>"
//"            <script>$( document ).ready(function() { t396_init('97269753');"
//"               });"
//"            </script><!-- /T396 -->"
//"         </div>"
//"      </div>"
//"      <!--/allrecords--><!-- Tilda copyright. Don't remove this line -->"
//"      <div class=\"t-tildalabel t-tildalabel-free\" id=\"tildacopy\" data-tilda-sign=\"733847#5359855\">"
//"         <div class=\"t-tildalabel-free__main\">"
//"            <a href=\"https://tilda.cc/?upm=733847\" target=\"_blank\" style=\"padding-bottom:12px; display: block;\"><img style=\"width:40px;\" src=\"https://static.tildacdn.com/img/tildacopy.png\"></a>"
//"            <div style=\"padding-bottom: 15px;\">This site was made on <a href=\"https://tilda.cc/?upm=733847\" target=\"_blank\" style=\"text-decoration: none; color:inherit;\">Tilda &mdash; a website builder</a> that helps to&nbsp;create a&nbsp;website without any code</div>"
//"            <a href=\"https://tilda.cc/registration/\" target=\"_blank\" style=\"display: inline-block; padding: 10px 20px; font-size: 13px; border-radius: 50px; background-color: #fff; color:#000; text-decoration: none;\">Create a website</a>"
//"         </div>"
//"         <div class=\"t-tildalabel-free__links-wr\"><a class=\"t-tildalabel-free__txt-link\" href=\"http://help.tilda.ws/white-label\" target=\"_blank\">How to remove this block?</a><a class=\"t-tildalabel-free__txt-link\" href=\"https://tilda.cc/?upm=733847\" target=\"_blank\">About platform</a><a class=\"t-tildalabel-free__txt-link\" href=\"https://tilda.cc/abuse/\" target=\"_blank\">Submit a complaint</a></div>"
//"      </div>"
//"      <!-- Stat --><script type=\"text/javascript\">if (! window.mainTracker) { window.mainTracker = 'tilda'; }	(function (d, w, k, o, g) { var n=d.getElementsByTagName(o)[0],s=d.createElement(o),f=function(){n.parentNode.insertBefore(s,n);}; s.type = \"text/javascript\"; s.async = true; s.key = k; s.id = \"tildastatscript\"; s.src=g; if (w.opera==\"[object Opera]\") {d.addEventListener(\"DOMContentLoaded\", f, false);} else { f(); } })(document, window, '2814db92f3552d1c567c64f73c9b42b9','script','https://stat.tildacdn.com/js/tildasimplestat-0.1.min.js');</script>"
//"   </body>"
//"</html>";
}
//---------------------------------------------------------------------------


void __fastcall TWebModule1::WebModule1WebActionItem1Action(TObject *Sender, TWebRequest *Request,
          TWebResponse *Response, bool &Handled)
{
   Response->Content = PageProducer1->Content();
}
//---------------------------------------------------------------------------
void __fastcall TWebModule1::PageProducer2HTMLTag(TObject *Sender, TTag Tag, const UnicodeString TagString,
		  TStrings *TagParams, UnicodeString &ReplaceText)
{
	ReplaceText = Request->QueryFields->Values[TagString] + Request->ContentFields->Values[TagString];
	UnicodeString st = Request->QueryFields->Values[TagString];
	st += Request->ContentFields->Values[TagString];
	st += " ";
}
//---------------------------------------------------------------------------

void __fastcall TWebModule1::PageProducerDefHTMLTag(TObject *Sender, TTag Tag, const UnicodeString TagString,
          TStrings *TagParams, UnicodeString &ReplaceText)
{
	ReplaceText = Request->QueryFields->Values[TagString] + Request->ContentFields->Values[TagString];
	UnicodeString st = Request->QueryFields->Values[TagString];
	st += Request->ContentFields->Values[TagString];
	st += " ";
}
//---------------------------------------------------------------------------

void __fastcall TWebModule1::WebModule1WebActionItem2Action(TObject *Sender, TWebRequest *Request,
          TWebResponse *Response, bool &Handled)
{
	UnicodeString st = "�����: ";
	st += Request->QueryFields->Values["T2"] +
		  Request->ContentFields->Values["T2"];
	st += "\r\n";
	st += Request->QueryFields->Values["T4"] +
		  Request->ContentFields->Values["T4"];
	ShowMessage(st);
}
//---------------------------------------------------------------------------

