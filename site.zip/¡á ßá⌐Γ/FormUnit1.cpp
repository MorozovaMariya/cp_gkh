
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FormUnit1.h"
#include "include/curl/curl.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonStartClick(TObject *Sender)
{
  StartServer();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonStopClick(TObject *Sender)
{
  FServer->Active = false;
  FServer->Bindings->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonOpenBrowserClick(TObject *Sender)
{
  StartServer();
  String url;
  url.sprintf(L"http://localhost:%s", EditPort->Text.c_str());
//  url.sprintf(L"http://smarttyumen.tilda.ws/#rec97269753");
  ShellExecuteW(0,
		NULL,
        url.c_str(),
        NULL, NULL, SW_SHOWNOACTIVATE);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ApplicationEvents1Idle(TObject *Sender, bool &Done)
{
  ButtonStart->Enabled = !FServer->Active;
  ButtonStop->Enabled = FServer->Active;
  EditPort->Enabled = !FServer->Active;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::StartServer()
{
  if (!FServer->Active)
  {
    FServer->Bindings->Clear();
    FServer->DefaultPort = StrToInt(EditPort->Text);
    FServer->Active = true;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  FServer = new TIdHTTPWebBrokerBridge(this);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button1Click(TObject *Sender)
{
	AnsiString url = "http://192.168.137.1:8000/Security/Account/LogOn";
	TStringStream *stream = new TStringStream();

	TStringList *List = new TStringList;



//IdHTTP1->Request->CacheControl = "no-cache";
//IdHTTP1->Request->Connection = "keep-alive";
//IdHTTP1->Request->ContentLength = 5;
//IdHTTP1->Request->AcceptEncoding = "gzip, deflate";
//IdHTTP1->Request->Host = "ecm-demo.elma-bpm.ru";
//IdHTTP1->Request->Accept = "**";     //???  dHTTP1->Request->Accept = "*//*";
//IdHTTP1->Request->UserAgent = "PostmanRuntime/7.15.0";
//IdHTTP1->Request->ContentType = "application/json; charset=utf-8";

//headers = curl_slist_append(headers, "cache-control: no-cache");
//headers = curl_slist_append(headers, "Connection: keep-alive");
//headers = curl_slist_append(headers, "content-length: 5");
//headers = curl_slist_append(headers, "accept-encoding: gzip, deflate");
//headers = curl_slist_append(headers, "Host: ecm-demo.elma-bpm.ru");
//headers = curl_slist_append(headers, "Postman-Token: fc4222db-ad13-4048-9068-a214e9b89b67,897c8208-b677-4c28-b2eb-1f027e7299f5");
//headers = curl_slist_append(headers, "Cache-Control: no-cache");
//headers = curl_slist_append(headers, "Accept: */*");
//headers = curl_slist_append(headers, "User-Agent: PostmanRuntime/7.15.0");
//headers = curl_slist_append(headers, "webdata-version: 2.0");
//headers = curl_slist_append(headers, "Content-Type: application/json; charset=utf-8");
//headers = curl_slist_append(headers, "ApplicationToken: 285C8352AA7C67BFF882E4F236DECF51098C141AFB33A2AA4F7B34B4B3CEEF5DA30C848591DA55D5226C5D8D2C36432B12A5EF86C3D2EDF7E7C5781EC9D4E14A");
//curl_easy_setopt(hnd, CURLOPT_HTTPHEADER, headers);
//
//curl_easy_setopt(hnd, CURLOPT_POSTFIELDS, "\"123\"");


//__RequestVerificationToken

//List->Add("name='login'");
//name="login"


/*
	List->Add("123");
	List->Add("ApplicationToken=285C8352AA7C67BFF882E4F236DECF51098C141AFB33A2AA4F7B34B4B3CEEF5DA30C848591DA55D5226C5D8D2C36432B12A5EF86C3D2EDF7E7C5781EC9D4E14A");
IdHTTP1->Request->CacheControl = "no-cache";
IdHTTP1->Request->Connection = "keep-alive";
IdHTTP1->Request->ContentLength = 5;
IdHTTP1->Request->AcceptEncoding = "gzip, deflate";
IdHTTP1->Request->Host = "ecm-demo.elma-bpm.ru";
IdHTTP1->Request->Accept = "**";     //???  dHTTP1->Request->Accept = "*//*";
IdHTTP1->Request->UserAgent = "PostmanRuntime/7.15.0";
IdHTTP1->Request->ContentType = "application/json; charset=utf-8";
*/


	try
	{
		IdHTTP1->Post(url,List,stream);
	}
	catch(EIdException &E)
	{
		ShowMessage("������:\n"+E.Message);
	}
	ShowMessage(stream->DataString);
	delete stream;
	delete List;

//CURL *hnd = curl_easy_init();
//
//curl_easy_setopt(hnd, CURLOPT_CUSTOMREQUEST, "POST");
//curl_easy_setopt(hnd, CURLOPT_URL, "http://192.168.137.1:8000/API/REST/Authorization/LoginWith?username=HCSSiteUser");
//
//struct curl_slist *headers = NULL;
//headers = curl_slist_append(headers, "cache-control: no-cache");
//headers = curl_slist_append(headers, "Connection: keep-alive");
//headers = curl_slist_append(headers, "content-length: 12");
//headers = curl_slist_append(headers, "accept-encoding: gzip, deflate");
//headers = curl_slist_append(headers, "Host: localhost:8000");
//headers = curl_slist_append(headers, "Postman-Token: 0a86b7b8-f068-41f0-8995-12c34e11b28d,d415f0f9-4682-4af7-ae45-db6f6ce5af97");
//headers = curl_slist_append(headers, "Cache-Control: no-cache");
//headers = curl_slist_append(headers, "Accept: */*");
//headers = curl_slist_append(headers, "User-Agent: PostmanRuntime/7.15.0");
//headers = curl_slist_append(headers, "webdata-version: 2.0");
//headers = curl_slist_append(headers, "Content-Type: application/json; charset=utf-8");
//headers = curl_slist_append(headers, "ApplicationToken: 3903EEEF287079FE3340A9BD5E71327160840476BC725B426889CAA2371A3CDDD4D27B3B868149A0BF62EE3664A5FC6983981EA0B74FF03253B92B06AA12E499");
//curl_easy_setopt(hnd, CURLOPT_HTTPHEADER, headers);
//
//curl_easy_setopt(hnd, CURLOPT_POSTFIELDS, "\"MWBraLb7kH\"");
//
//CURLcode ret = curl_easy_perform(hnd);
}
//---------------------------------------------------------------------------



void __fastcall TForm1::Button2Click(TObject *Sender)
{
AnsiString url = "http://192.168.137.1:8000/API/REST/Authorization/LoginWith?username=HCSSiteUser";
 TStringStream *stream = new TStringStream();

 TStringList *List = new TStringList;

 IdHTTP1->Request->Username = "HCSSiteUser";

 TIdHeaderList *hList = new TIdHeaderList(QuotePlain);
 hList->AddValue("ApplicationToken", "3903EEEF287079FE3340A9BD5E71327160840476BC725B426889CAA2371A3CDDD4D27B3B868149A0BF62EE3664A5FC6983981EA0B74FF03253B92B06AA12E499");
 hList->AddValue("Content-Type", "application/json; charset=utf-8");
 hList->AddValue("webdata-version", "2.0");
 List->Add("\"MWBraLb7kH\"");
// const char a[] = "ApplicationToken=3903EEEF287079FE3340A9BD5E71327160840476BC725B426889CAA2371A3CDDD4D27B3B868149A0BF62EE3664A5FC6983981EA0B74FF03253B92B06AA12E499";
// const char b[] = "Content-Type=application/json; charset=utf-8";
// const char c[] = "webdata-version=2.0";
// IdHTTP1->Request->RawHeaders->
//IdHTTP1->Request->RawHeaders = hList;
//IdHTTP1->Request->RawHeaders->AddValue("ApplicationToken", "3903EEEF287079FE3340A9BD5E71327160840476BC725B426889CAA2371A3CDDD4D27B3B868149A0BF62EE3664A5FC6983981EA0B74FF03253B92B06AA12E499");
//IdHTTP1->Request->RawHeaders->AddValue("Content-Type", "application/json; charset=utf-8");
//IdHTTP1->Request->RawHeaders->AddValue("webdata-version", "2.0");
IdHTTP1->Request->CustomHeaders = hList;
//IdHTTP1->Request->RawHeaders-> = hList;
IdHTTP1->Request->CacheControl = "no-cache";
IdHTTP1->Request->Connection = "keep-alive";
IdHTTP1->Request->ContentLength = 12;
IdHTTP1->Request->AcceptEncoding = "gzip, deflate";
//IdHTTP1->Request->Host = "ecm-demo.elma-bpm.ru";
IdHTTP1->Request->Accept = "*/*";
IdHTTP1->Request->UserAgent = "PostmanRuntime/7.15.0";
IdHTTP1->Request->ContentType = "application/json; charset=utf-8";

//headers = curl_slist_append(headers, "cache-control: no-cache");
//headers = curl_slist_append(headers, "Connection: keep-alive");
//headers = curl_slist_append(headers, "content-length: 5");
//headers = curl_slist_append(headers, "accept-encoding: gzip, deflate");
//headers = curl_slist_append(headers, "Host: ecm-demo.elma-bpm.ru");
//headers = curl_slist_append(headers, "Postman-Token: fc4222db-ad13-4048-9068-a214e9b89b67,897c8208-b677-4c28-b2eb-1f027e7299f5");
//headers = curl_slist_append(headers, "Cache-Control: no-cache");
//headers = curl_slist_append(headers, "Accept: */*");
//headers = curl_slist_append(headers, "User-Agent: PostmanRuntime/7.15.0");
//headers = curl_slist_append(headers, "webdata-version: 2.0");
//headers = curl_slist_append(headers, "Content-Type: application/json; charset=utf-8");
//headers = curl_slist_append(headers, "ApplicationToken: 285C8352AA7C67BFF882E4F236DECF51098C141AFB33A2AA4F7B34B4B3CEEF5DA30C848591DA55D5226C5D8D2C36432B12A5EF86C3D2EDF7E7C5781EC9D4E14A");
//curl_easy_setopt(hnd, CURLOPT_HTTPHEADER, headers);
//
//curl_easy_setopt(hnd, CURLOPT_POSTFIELDS, "\"123\"");




 try
 {
  IdHTTP1->Post(url,List,stream);
 }
 catch(EIdException &E)
 {
  ShowMessage("������:\n"+E.Message);
 }
 ShowMessage(stream->DataString);
 delete stream;
 delete List;

//CURL *hnd = curl_easy_init();
//
//curl_easy_setopt(hnd, CURLOPT_CUSTOMREQUEST, "POST");
//curl_easy_setopt(hnd, CURLOPT_URL, "http://192.168.137.1:8000/API/REST/Authorization/LoginWith?username=HCSSiteUser");
//
//struct curl_slist *headers = NULL;
//headers = curl_slist_append(headers, "cache-control: no-cache");
//headers = curl_slist_append(headers, "Connection: keep-alive");
//headers = curl_slist_append(headers, "content-length: 12");
//headers = curl_slist_append(headers, "accept-encoding: gzip, deflate");
//headers = curl_slist_append(headers, "Host: localhost:8000");
//headers = curl_slist_append(headers, "Postman-Token: 0a86b7b8-f068-41f0-8995-12c34e11b28d,d415f0f9-4682-4af7-ae45-db6f6ce5af97");
//headers = curl_slist_append(headers, "Cache-Control: no-cache");
//headers = curl_slist_append(headers, "Accept: */*");
//headers = [������]   �����������    http://ecm-demo.elma-bpm.ru   curl_slist_append(headers, "User-Agent: PostmanRuntime/7.15.0");
//headers = curl_slist_append(headers, "webdata-version: 2.0");
//headers = curl_slist_append(headers, "Content-Type: application/json; charset=utf-8");
//headers = curl_slist_append(headers, "ApplicationToken: 3903EEEF287079FE3340A9BD5E71327160840476BC725B426889CAA2371A3CDDD4D27B3B868149A0BF62EE3664A5FC6983981EA0B74FF03253B92B06AA12E499");
//curl_easy_setopt(hnd, CURLOPT_HTTPHEADER, headers);
//
//curl_easy_setopt(hnd, CURLOPT_POSTFIELDS, "\"MWBraLb7kH\"");
//
//CURLcode ret = curl_easy_perform(hnd);


;
}
//---------------------------------------------------------------------------

