// insert JavaScript source code here


    var settings = {
  "async": true,
  "crossDomain": true,
  "url": "http://ecm-demo.elma-bpm.ru/API/REST/Authorization/LoginWith?username=test",
  "method": "POST",
  "headers": {
    "ApplicationToken": "285C8352AA7C67BFF882E4F236DECF51098C141AFB33A2AA4F7B34B4B3CEEF5DA30C848591DA55D5226C5D8D2C36432B12A5EF86C3D2EDF7E7C5781EC9D4E14A",
    "Content-Type": "application/json; charset=utf-8",
    "webdata-version": "2.0",
    "User-Agent": "PostmanRuntime/7.15.0",
    "Accept": "*/*",
    "Cache-Control": "no-cache",
    "Postman-Token": "fc4222db-ad13-4048-9068-a214e9b89b67,9628a2f1-6309-44b7-90c5-44e1261e8e9e",
    "Host": "ecm-demo.elma-bpm.ru",
    "accept-encoding": "gzip, deflate",
    "content-length": "5",
    "Connection": "keep-alive",
    "cache-control": "no-cache"
  },
  "data": "\"123\""
}

